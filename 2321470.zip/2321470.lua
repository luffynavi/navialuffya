-- 2321470's Lua and Manifest Created by Morrenus
-- Deep Rock Galactic: Survivor
-- Created: December 15, 2025 at 12:33:57 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(2321470) -- Deep Rock Galactic: Survivor
-- MAIN APP DEPOTS
addappid(2321471, 1, "18154d412c1c3c3719d8f05c119354536a5228cdd169ca75488708a215c1cddf") -- Depot 2321471
setManifestid(2321471, "8460921902531021286", 3621147284)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2782850) -- Deep Rock Galactic Survivor - Supporter Pack
addappid(3818560) -- Deep Rock Galactic Survivor - After Hours Pack