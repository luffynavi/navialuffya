addappid(2371890)
addappid(2371891,0,"6c815221d8d9cfee2f7049bb20c038fa503207a88f68e512ff829f0fc052bbaa")
setManifestid(2371891,"4741862926634955477")




--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]