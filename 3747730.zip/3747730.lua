-- MAIN APPLICATION
addappid(3747730) -- Legacy of Kain: Defiance Remastered
-- MAIN APP DEPOTS
addappid(3747731, 1, "0a18d0fd686b8964dbbcb018dc604057a52e80b40a3ed2953f65f9c9ad754cb4") -- Depot 3747731
setManifestid(3747731, "5525805609814582770", 21179115665)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4134770) -- Legacy of Kain Defiance Remastered - Deluxe Upgrade Pack
addappid(4134780) -- Legacy of Kain Defiance Remastered - Shifter Skin Pack
addappid(4230170) -- Legacy of Kain Defiance Remastered - Ascendance Skin Pack