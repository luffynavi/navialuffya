-- MAIN APPLICATION
addappid(2495100, 1, "1ecc51445b889a210ab4d96808d9f4f7f751923152c3a5e6b56a5002833e217b") -- Hello Kitty Island Adventure
-- MAIN APP DEPOTS
addappid(2495101, 1, "62b02a1a603b53787ec2fea81ea2b505fdca436fa17d52d82e3df9097e14fab7") -- Depot 2495101
setManifestid(2495101, "146974170489605744", 4506725157)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3359740) -- Hello Kitty Island Adventure - Deluxe Edition
addappid(3890520) -- Hello Kitty Island Adventure - Wheatflour Wonderland