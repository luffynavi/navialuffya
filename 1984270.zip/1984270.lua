

-- MAIN APPLICATION
addappid(1984270, 1, "60f0f52f51592d35101a1678ff221736cee376b3a9db46229f5164dd95b70add") -- Digimon Story Time Stranger
-- MAIN APP DEPOTS
addappid(1984271, 1, "b0aa8ddfef2996e3122b0bda1d02f7ceb28f608ac8c1d853e6793790aaab8860") -- Depot 1984271
setManifestid(1984271, "8059058061631208231", 31717559378)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- .NET 4.8 Redist (Shared from App 228980)
setManifestid(229007, "4477590687906973371", 117381405)
-- DLCS WITH DEDICATED DEPOTS
-- Digimon Story Time Stranger - Pre-Order Bonus Pack (AppID: 3524240)
addappid(3524240)
addappid(3524240, 1, "f06dc8a525a2fb5e03453da570b80915bd7c02daae714ac854c86283a2bc4e18") -- Digimon Story Time Stranger - Pre-Order Bonus Pack - Depot 3524240
setManifestid(3524240, "8093752377166947780", 44591213)
-- Digimon Story Time Stranger - Farm Item Golden Moai (AppID: 3524250)
addappid(3524250)
addappid(3524250, 1, "b6c098c1cdd8687907373e2a6e59446445aafca92e10fe4da2c59481f0448f24") -- Digimon Story Time Stranger - Farm Item Golden Moai - Depot 3524250
setManifestid(3524250, "6473051103911318870", 145601)
-- Digimon Story Time Stranger - Additional Digimon  Episode Pack 1 Alternate Dimension (AppID: 3524260)
addappid(3524260)
addappid(3524260, 1, "0d0cb59fa779a35a600989d6bbbd8a43d4459245ff74f28b125e3089d2c59940") -- Digimon Story Time Stranger - Additional Digimon  Episode Pack 1 Alternate Dimension - Depot 3524260
setManifestid(3524260, "7118783550441334024", 227383814)
-- Digimon Story Time Stranger - Additional Digimon  Episode Pack 2 GAKURAN (AppID: 3524270)
addappid(3524270)
addappid(3524270, 1, "efc19afeba78735ba1acc7264f8363b01d290e19fd5bbde3c9b6956d6dbbd750") -- Digimon Story Time Stranger - Additional Digimon  Episode Pack 2 GAKURAN - Depot 3524270
setManifestid(3524270, "386479390692777446", 228137649)
-- Digimon Story Time Stranger - Costume Cyber Sleuth Set (AppID: 3524300)
addappid(3524300)
addappid(3524300, 1, "0ae80de6e7b2f3ec166de6a98b3f6a018af9fba6c54f144916d1f4ab07671b2c") -- Digimon Story Time Stranger - Costume Cyber Sleuth Set - Depot 3524300
setManifestid(3524300, "2166254318281553691", 32400924)
-- Digimon Story Time Stranger - Early Unlock Special Agumon  Gabumon (AppID: 3524310)
addappid(3524310)
addappid(3524310, 1, "5f8a85a36740263fe78affe346fd7b0c18eb7ad2a51537a2c875f64fa080cbf1") -- Digimon Story Time Stranger - Early Unlock Special Agumon  Gabumon - Depot 3524310
setManifestid(3524310, "4165550793860729153", 4319)
-- Digimon Story Time Stranger - Costume Swimwear Set (AppID: 3524320)
addappid(3524320)
addappid(3524320, 1, "0da086161abea2f6ce0863a530fefc41ac12993fb4308ff16301926398803a27") -- Digimon Story Time Stranger - Costume Swimwear Set - Depot 3524320
setManifestid(3524320, "2937343108483999987", 4902)
-- Digimon Story Time Stranger - Costume Chosen Children Set (AppID: 3524330)
addappid(3524330)
addappid(3524330, 1, "2358d5ff200cefb1eef6f77277f04089a01daaea4418cd48d530b4de3fe53f61") -- Digimon Story Time Stranger - Costume Chosen Children Set - Depot 3524330
setManifestid(3524330, "6969047721551132609", 2826)
-- Digimon Story Time Stranger - Costume Digimon Costume Set (AppID: 3524340)
addappid(3524340)
addappid(3524340, 1, "5441f08ccf7ebad6314bac9d071ba47a41e709f4000e121004752959138bb2dc") -- Digimon Story Time Stranger - Costume Digimon Costume Set - Depot 3524340
setManifestid(3524340, "1407478222003555040", 1024)
-- Digimon Story Time Stranger -  Costume Public Safety Suit  Special Supplies Set (AppID: 3524350)
addappid(3524350)
addappid(3524350, 1, "388eb5d2862631b327cd83e312bc69e3f14ecf6087a6a2ec0860f20df764139d") -- Digimon Story Time Stranger -  Costume Public Safety Suit  Special Supplies Set - Depot 3524350
setManifestid(3524350, "8358207152149625529", 306074)
-- Digimon Story Time Stranger - Cyber Sleuth BGM Pack (AppID: 3524360)
addappid(3524360)
addappid(3524360, 1, "9ac71aa654d8726aaf514236b138ac5c075854dd8f33abbfeb1b4316302c7f7b") -- Digimon Story Time Stranger - Cyber Sleuth BGM Pack - Depot 3524360
setManifestid(3524360, "7211903957130876538", 361772040)
-- Digimon Story Time Stranger - Digimon Anime Song Pack (AppID: 3524370)
addappid(3524370)
addappid(3524370, 1, "a20f41adefa6edd0b1a0644a6e359437cc9476624a4e80b6b31d90c893fb3577") -- Digimon Story Time Stranger - Digimon Anime Song Pack - Depot 3524370
setManifestid(3524370, "6986306072105643967", 47812936)
-- Digimon Story Time Stranger - Outer Dungeons The Halls of EXP, Gold, Materials (AppID: 3524380)
addappid(3524380)
addappid(3524380, 1, "4ef7dc743aea30597adbffc2215a364e119c16ab160dc2f20ae358296d12f4bf") -- Digimon Story Time Stranger - Outer Dungeons The Halls of EXP, Gold, Materials - Depot 3524380
setManifestid(3524380, "9165147238607416395", 2472)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3524390) -- Digimon Story Time Stranger - Season Pass
addappid(3524400) -- Digimon Story Time Stranger - Costume Pack
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1984272) -- Depot 1984272 (empty depot)