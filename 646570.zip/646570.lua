-- 646570's Lua and Manifest Created by Morrenus
-- Slay the Spire
-- Created: September 30, 2025 at 14:45:13 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 6
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(646570, 1, "4794cf193a25b70a28f151dc8f05e4e92fa57074d42afc4749b59dd40ae56508") -- Slay the Spire
-- MAIN APP DEPOTS
addappid(646572, 1, "d46524b47e7a9384e6b575394a6e96940634c8db3f58e829182eb486ca60e425") -- Slay the Spire Mac
setManifestid(646572, "2910015420030023273", 471113092)
addappid(646573, 1, "7b0997618ad03031136f9caa6811f5d2c08ee7e0ac4b9c745675f12fd0354ee4") -- Slay the Spire Linux
setManifestid(646573, "5221386008033040636", 573377566)
addappid(646574, 1, "85867004baa33349870d65ae84baac02f1a0e0280462a7b6f41912a30e008955") -- Slay the Spire Windows32
setManifestid(646574, "6089130681980710352", 538030886)
addappid(646571, 1, "af36e1914da16f3e4556bedf7e46a76646b670c91bb6e1d3cca380e16ceb2df6") -- Slay the Spire Windows
setManifestid(646571, "9072802409324604124", 541513970)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(877621, 1, "9aebfbce314584af6e967104be1d5060284feca4baef886010adc9c4a983b4fc") -- Slay the Spire - Soundtrack Depot (Shared from App 877620)
setManifestid(877621, "1616206291221819177", 153829851)