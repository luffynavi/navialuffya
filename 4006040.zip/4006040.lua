-- Name: VEGAS Pro 23 Steam Edition
-- AppID: 4006040

addappid(4006040)
addappid(4006040,0)
addappid(4006041,0,"7e1e29a2c518925c472bae0cfbd6cd1cb07716174dff3871257741094a2ef0b8")
