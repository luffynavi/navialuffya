
-- MAIN APPLICATION
addappid(3595230, 1, "32818f3b3fa1e44fc4be8477e3aa203c06786e5ec85d26d7db8260579649fd8b") -- Call of Duty®: Modern Warfare® II
-- MAIN APP DEPOTS
addappid(3603196, 1, "5fa7fec1a1b49284c9c7a71339463561de33da4153ac0505e6ab4cc98302342e") -- Depot 3603196
setManifestid(3603196, "2478578705665376566", 25297918897)
addappid(3603197, 1, "0e3c160ee7cb0b60222663b089596cfff8ebb8fac721d8dffae7344f8da77a55") -- Depot 3603197
setManifestid(3603197, "3394223495559782177", 786671157)
addappid(3603198, 1, "b2b665208413b45c729645b2674090159ecebf4d43676456e7ec98427ff6a020") -- Depot 3603198
setManifestid(3603198, "8957710439420083405", 2134235240)
addappid(3603199, 1, "fa788d2f146a13cd906f470e55189c7091a835862b53cad30d5e88b9704b5cef") -- Depot 3603199
setManifestid(3603199, "6360695348678223704", 4350144380)
addappid(3603201, 1, "31560f2ea5525add6ebca6ffaefdbc6d784b65f7b439138b969a5fb733c12ec2") -- Depot 3603201
setManifestid(3603201, "8102337478878896324", 4546793884)
addappid(3603202, 1, "d339e2a3c1b3cf07905c83732abd404dca1e2ba14c5691e7ca18cd7ec7c42513") -- Depot 3603202
setManifestid(3603202, "4238086339497096229", 4532318332)
addappid(3603203, 1, "edeaf8e1ca7f1ed6443953f00cae03ce6c5bb25e58138988cdc6b05bf23a0a63") -- Depot 3603203
setManifestid(3603203, "7267042668121240748", 4678572260)
addappid(3603204, 1, "d4fcd5a220a5fd3aa7211adbfe1530c33dacd75b5307fe13a41d96ff2441d06b") -- Depot 3603204
setManifestid(3603204, "8619622256582714889", 6294734264)
addappid(3603205, 1, "acdfaa6aca1807a552f2b918400d46fe324a291564dce05b8af842f7b6bce2ca") -- Depot 3603205
setManifestid(3603205, "1047902873993041920", 4488672300)
addappid(3603206, 1, "c0a3b15e842d9e27bd9b9da512d72145fe98f1f8f9eacd24a2b9e8869375287a") -- Depot 3603206
setManifestid(3603206, "7768339653543322151", 4655737208)
addappid(3603207, 1, "fe7ac7e83fd84ac3441823157a20773d6bcc1f4c57ccddd43cb4042058b4b9aa") -- Depot 3603207
setManifestid(3603207, "2666581385993758995", 4282475808)
addappid(3603208, 1, "c7e5f6854135113d38b56a4458e1b7b7863e01abaa3a649a0c091b13927b7d48") -- Depot 3603208
setManifestid(3603208, "2640239863309432192", 4282343600)
addappid(3603209, 1, "ca9a5948d4e9aa1a9fa2a109dff450d10dbf991092e90818dfbfe08a47f17b07") -- Depot 3603209
setManifestid(3603209, "209080240319266906", 4270507540)
addappid(3603211, 1, "241f8de297a21bab22954aed05514188bb61e48eb7bed45ea18191df3eb7980e") -- Depot 3603211
setManifestid(3603211, "1910107727040835767", 6590886424)
addappid(3603212, 1, "51486a6f48050bc56b787b37b73fd71b4fa6fb7d9ad2dbc8ee7cf26c8e96a440") -- Depot 3603212
setManifestid(3603212, "3606842175277898752", 6648229160)
addappid(3603213, 1, "f86835dca998aa9b0a57228332d92c539fec131a0e90746c311b7f1489cd6d96") -- Depot 3603213
setManifestid(3603213, "3140253377382080716", 6764430064)
addappid(3603214, 1, "cca02853cbb78e10b88e051d6b80dbb0b5ad7dc384ceeeca7395c785d34dd685") -- Depot 3603214
setManifestid(3603214, "6767943252810329117", 4829140440)
addappid(3603215, 1, "cfbe70a2765fd23fc9e18fc709477bc89b613a9dbe33e963b958f02d5bf580c7") -- Depot 3603215
setManifestid(3603215, "5797612927145053079", 31859324)
addappid(3603216, 1, "7bafc467a7b07bf3e3a58d4eb247020eed3fde6a23feaa8cdc1fc51792ab241b") -- Depot 3603216
setManifestid(3603216, "6852925740351040045", 31713840)
addappid(3603217, 1, "3a795498fcf75753a482b02d6362056bea7065cd50e1fc58c04b1e57cfe4934e") -- Depot 3603217
setManifestid(3603217, "6341775747662699633", 28681184)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
-- DLCS WITH DEDICATED DEPOTS
-- Call of Duty Modern Warfare II - Campaign (AppID: 3602840)
addappid(3602840)
addappid(3602840, 1, "9f6de3e5b29ab7ba7f72305d430f9935a052a51abd13178982074fd89d8bbb07") -- Call of Duty Modern Warfare II - Campaign - Depot 3602840
setManifestid(3602840, "5389317900021246171", 24963065240)
addappid(3595232, 1, "86bf4f331b149631dec1cb4743ef216c7f60c9e39e6cc5dfd1484dc86f3f9c3a") -- Call of Duty Modern Warfare II - Campaign - Depot 3595232
setManifestid(3595232, "6495836662819384127", 474363976)
addappid(3595233, 1, "517fcd348526034a9b52aff71df25f457b38f3650243811b7ba7cf2fe5961278") -- Call of Duty Modern Warfare II - Campaign - Depot 3595233
setManifestid(3595233, "1401089134170976246", 841955392)
addappid(3595234, 1, "f34f1f102e541fc825f9f757d78affcddad0eb755bf325fda3cfd25298e80c23") -- Call of Duty Modern Warfare II - Campaign - Depot 3595234
setManifestid(3595234, "7930293368458633016", 1699333744)
addappid(3595235, 1, "cb68013d96f6dc58dd7d941bd23c06632a26d3d0ae6478601d911bed8aa81093") -- Call of Duty Modern Warfare II - Campaign - Depot 3595235
setManifestid(3595235, "3764637003499097279", 1721593644)
addappid(3595236, 1, "96cbf11147270543d3a832f1c27bf3537c0b41c290ed5977a5d659980302feb8") -- Call of Duty Modern Warfare II - Campaign - Depot 3595236
setManifestid(3595236, "5646029562563686557", 1722317928)
addappid(3595237, 1, "700379a2cffdc42e1d846c3981981eeab4319477c076e8fa90fb61e3048d1719") -- Call of Duty Modern Warfare II - Campaign - Depot 3595237
setManifestid(3595237, "1603780920805892213", 1745417392)
addappid(3595238, 1, "613e3387b70e5669ed6d2be5d43372e671637f95fd193d5ca11fb14ca2c28eea") -- Call of Duty Modern Warfare II - Campaign - Depot 3595238
setManifestid(3595238, "89209264206128051", 2532735236)
addappid(3595239, 1, "b047fa5c5fcf08f0ec99c4acdaae951cccdcb39254b56a863cba3134e464fe3e") -- Call of Duty Modern Warfare II - Campaign - Depot 3595239
setManifestid(3595239, "7823202341337271386", 1722258384)
addappid(3602841, 1, "0e393628a69b036318d277ef4a8e659ed58367672c5bb7cfde7d6b1762d711a1") -- Call of Duty Modern Warfare II - Campaign - Depot 3602841
setManifestid(3602841, "6959104914601260698", 1736486176)
addappid(3602842, 1, "c14b7b3a07615f5ed3a0148eff86ffb6707e87b4c99c9851227a5f5f3463ed92") -- Call of Duty Modern Warfare II - Campaign - Depot 3602842
setManifestid(3602842, "1144605817155797124", 1697977312)
addappid(3602843, 1, "165b997fae3ce61cf9d33ab235aefb82fed92b13954d815f95511e0506740d4a") -- Call of Duty Modern Warfare II - Campaign - Depot 3602843
setManifestid(3602843, "7915227427429312838", 1697896316)
addappid(3602844, 1, "128a5a65edf9385f4d9024e1f2f8576527ccb2248a905faf3614e977c4883e9d") -- Call of Duty Modern Warfare II - Campaign - Depot 3602844
setManifestid(3602844, "7276062035850538612", 1684849744)
addappid(3602845, 1, "6b8939e8b0eae1b95414790fc0490244851bdc263248040d1fd26867f470104e") -- Call of Duty Modern Warfare II - Campaign - Depot 3602845
setManifestid(3602845, "8473465838531817155", 2585601356)
addappid(3602846, 1, "00c01615ad5def68b96c3697f1d4cda02d59d35bcd5bef82759b42d6a67e8c74") -- Call of Duty Modern Warfare II - Campaign - Depot 3602846
setManifestid(3602846, "6017589421959610966", 2554292372)
addappid(3602847, 1, "17556ebbbb9aecc5ff6081c186e064383394175937c02372e3fbde27da58e951") -- Call of Duty Modern Warfare II - Campaign - Depot 3602847
setManifestid(3602847, "3769264507041514076", 2582902772)
addappid(3602848, 1, "58829b3f351f6180267d51349d5fbcf9966a54c1c9351301e8a3628ae5c07b39") -- Call of Duty Modern Warfare II - Campaign - Depot 3602848
setManifestid(3602848, "260595667804672663", 841955392)
addappid(3602849, 1, "d3787b66085d81234340db85b95f5523d45dca0c41afb752c40355c27755ef46") -- Call of Duty Modern Warfare II - Campaign - Depot 3602849
setManifestid(3602849, "495131983024490472", 24498252)
addappid(3602852, 1, "77a4db08ae8b2b2a585b74dc21ef4a66df80d56e5c3fec37cc0b6faac2d170d5") -- Call of Duty Modern Warfare II - Campaign - Depot 3602852
setManifestid(3602852, "6171414722143491609", 21692328)
-- Call of Duty Modern Warfare II - Multiplayer (AppID: 3602850)
addappid(3602850)
addappid(3602850, 1, "9b696e7b45cfb8511760c5c654b6563b69638d35145c833e022be1228fb78dc7") -- Call of Duty Modern Warfare II - Multiplayer - Depot 3602850
setManifestid(3602850, "7170228761444113903", 19058346872)
addappid(3602854, 1, "e9340c8a10ff26d2477387f54cc4af1482f4cb37a6fc46d3a6e153c37e702b71") -- Call of Duty Modern Warfare II - Multiplayer - Depot 3602854
setManifestid(3602854, "7134251492112591067", 3810944)
addappid(3602855, 1, "89478c11b9037c4e4f7ee18194c4dddcb5697cb5c72ec41d2776dfe4fa7a2d9f") -- Call of Duty Modern Warfare II - Multiplayer - Depot 3602855
setManifestid(3602855, "3111918220233534802", 7625728)
addappid(3602856, 1, "6e51e2aa0f3250f3336c2df868ad732519bf1458e45a4297908963993b4bca0c") -- Call of Duty Modern Warfare II - Multiplayer - Depot 3602856
setManifestid(3602856, "6284256070158692354", 7657772)
addappid(3602857, 1, "412b68db3cb878afdd318d3ca9050a0bf5ac07ddc74f3593c40c5524a3536f56") -- Call of Duty Modern Warfare II - Multiplayer - Depot 3602857
setManifestid(3602857, "2412610633119740021", 7690596)
addappid(3602858, 1, "ab58674ad4c290303e19349f3695abd5dd17116ee7f1e9ace1f0069bd0a17287") -- Call of Duty Modern Warfare II - Multiplayer - Depot 3602858
setManifestid(3602858, "6876775331940569051", 7658196)
addappid(3602859, 1, "3d82fc491e346a2b92d3170450dcaefafc1957c8d714688462c7c69e88d1a5d7") -- Call of Duty Modern Warfare II - Multiplayer - Depot 3602859
setManifestid(3602859, "8961124517453311110", 11469892)
addappid(3602861, 1, "c8305912d1f906406e241bf70dcace7f4f52706c9f6ac2c03ef85fdf049e464d") -- Call of Duty Modern Warfare II - Multiplayer - Depot 3602861
setManifestid(3602861, "9089939418978821831", 7690136)
addappid(3602862, 1, "b61fb6fd2721303a6cd4d7782405d64645d43431c2bacc7c2fb5213da77bf643") -- Call of Duty Modern Warfare II - Multiplayer - Depot 3602862
setManifestid(3602862, "1456717274400409627", 7625276)
addappid(3602863, 1, "14bab0d154915f585d1402fe18b3acdff0b4dc99762553dabf1419cbb91e1ac4") -- Call of Duty Modern Warfare II - Multiplayer - Depot 3602863
setManifestid(3602863, "6327184290095951191", 7622608)
addappid(3602864, 1, "8c1edd7f8524954eaee672d0777cf8cb62c2b9e2c6c9bb3522448bdb122d1b9a") -- Call of Duty Modern Warfare II - Multiplayer - Depot 3602864
setManifestid(3602864, "4547881976252827176", 7656124)
addappid(3602865, 1, "63a72cb69482c49d3c75d3ac2cda9d3de557a6699c05d421629fdb19ac599ed4") -- Call of Duty Modern Warfare II - Multiplayer - Depot 3602865
setManifestid(3602865, "2478766574771083513", 7678924)
addappid(3602866, 1, "e8310f41386a8b26994dc579e2c55513ee7e4d0d284d9850971d67bc4906ef3a") -- Call of Duty Modern Warfare II - Multiplayer - Depot 3602866
setManifestid(3602866, "33392446555853275", 11606532)
addappid(3602867, 1, "5ec37805841b61c9e8f1c5983a1ad56609160d885acf61e536eb33c7eef1cb13") -- Call of Duty Modern Warfare II - Multiplayer - Depot 3602867
setManifestid(3602867, "8800674643124363578", 11506700)
addappid(3602868, 1, "7b86406d57757d2dc8a13cc1b1bf1e410162a7921fb9f01d6fdbb43f19e802b0") -- Call of Duty Modern Warfare II - Multiplayer - Depot 3602868
setManifestid(3602868, "8085925893630973585", 11527060)
addappid(3602869, 1, "eb7c7d7edc000396198f146345cf4fa1f8bc5da5902021e7142c77d0c45b8ecd") -- Call of Duty Modern Warfare II - Multiplayer - Depot 3602869
setManifestid(3602869, "2234433814992160791", 6947564)
addappid(3602971, 1, "4022998b07d9a59f1763b225802dc27260e9277abbf6dd7406054da4c3f8f14a") -- Call of Duty Modern Warfare II - Multiplayer - Depot 3602971
setManifestid(3602971, "5643052353120217765", 3896596)
addappid(3602973, 1, "903a4fa5d8e20d07ffddb85d72b2b757d2cb9ece4bf01a8065563effedd4e2cb") -- Call of Duty Modern Warfare II - Multiplayer - Depot 3602973
setManifestid(3602973, "4361688259543658003", 3896148)
-- Call of Duty Modern Warfare II - Co-op (AppID: 3602860)
addappid(3602860)
addappid(3602860, 1, "612d9407fb1b2aad0b5cc0f325141b0de471397636c901e9f732c9398e662381") -- Call of Duty Modern Warfare II - Co-op - Depot 3602860
setManifestid(3602860, "2063298751918385591", 7747460984)
addappid(3602975, 1, "cfcf4f0ca0f42ea5a422d80f0b3f754b71048680f1306229059adc8f86becf6b") -- Call of Duty Modern Warfare II - Co-op - Depot 3602975
setManifestid(3602975, "2610206585314935997", 371779656)
addappid(3602976, 1, "5fa153ad2067ee978f818689436703f0b4e200c818425c808b62bc01de269f7f") -- Call of Duty Modern Warfare II - Co-op - Depot 3602976
setManifestid(3602976, "5917108318835235740", 758501352)
addappid(3602977, 1, "0adbc4aef08b397a42bff53f62c7fb36e00c2768c55fd305800992d32e90416c") -- Call of Duty Modern Warfare II - Co-op - Depot 3602977
setManifestid(3602977, "3109020849035408374", 762650584)
addappid(3602978, 1, "0a082d82b1168a4efb4ac916fca30d4ae2ddd3a8dfb136134cc419ec6ae819e2") -- Call of Duty Modern Warfare II - Co-op - Depot 3602978
setManifestid(3602978, "3189542626866124745", 760426392)
addappid(3602979, 1, "fc4634f31e0ce400b361f615fd40dcb8b16f95dfd84d2cba299ba3e05b92ab73") -- Call of Duty Modern Warfare II - Co-op - Depot 3602979
setManifestid(3602979, "3686785039278621007", 776632400)
addappid(3603161, 1, "0b2c3a1a2f6e0b479ea8df4488dff5663978b562566e2e448c80626cd0569af5") -- Call of Duty Modern Warfare II - Co-op - Depot 3603161
setManifestid(3603161, "1216403024778989902", 768763708)
addappid(3603162, 1, "f9db12d135f48dc487510ebad4533ec90fbcc5eca23dd5c1e0c811bbac18dd5d") -- Call of Duty Modern Warfare II - Co-op - Depot 3603162
setManifestid(3603162, "7775347232920605411", 767636244)
addappid(3603163, 1, "3439c0cbb06cab1f58a2fc0e5813e82d567a904184c162a69204449b01deb763") -- Call of Duty Modern Warfare II - Co-op - Depot 3603163
setManifestid(3603163, "2562404794447042258", 743552056)
addappid(3603164, 1, "421cc58c870478a403164d232fd2622c1771762ebdb0b561ac97656dde3ba721") -- Call of Duty Modern Warfare II - Co-op - Depot 3603164
setManifestid(3603164, "3464103832406091505", 743801956)
addappid(3603165, 1, "5402410b223c13ff21b7e630c04926c1b8aeb992c6d2f8d36748180d80244837") -- Call of Duty Modern Warfare II - Co-op - Depot 3603165
setManifestid(3603165, "7010237796011125047", 744277164)
addappid(3603166, 1, "2486c67728becf22b89f29e446950582c337a4cf7573b0827f65945b47516487") -- Call of Duty Modern Warfare II - Co-op - Depot 3603166
setManifestid(3603166, "5971287816008331143", 1133215784)
addappid(3603167, 1, "14b5f2e6c8d35c3909d8a504c45b07f093e35756f6cbe6afc31c82450ec6ecd8") -- Call of Duty Modern Warfare II - Co-op - Depot 3603167
setManifestid(3603167, "2110993815340163750", 1131827664)
addappid(3603168, 1, "42138312e3e158d1bc4c60592aa47277dc0ba0eb2c1043b8013f805ae2627817") -- Call of Duty Modern Warfare II - Co-op - Depot 3603168
setManifestid(3603168, "3235514057226436851", 1167481676)
addappid(3603169, 1, "134de52441e2c3d9d6368c6aa52e13aa793cd197752caf20feefa7247a1c1a5a") -- Call of Duty Modern Warfare II - Co-op - Depot 3603169
setManifestid(3603169, "5762361503773362968", 376222724)
addappid(3603174, 1, "6ff7ec07aaec4286e3c7d8ac6c61dccaba8a40dfd52ca91b15d337598210fb49") -- Call of Duty Modern Warfare II - Co-op - Depot 3603174
setManifestid(3603174, "4105884187808736267", 1116265304)
addappid(3603171, 1, "8e776840849b36e68e72caf38b4749482bfac0c930021d671a2085db69755e33") -- Call of Duty Modern Warfare II - Co-op - Depot 3603171
setManifestid(3603171, "9031206097584138907", 3307456)
addappid(3603173, 1, "d6da20ad1f66ba510032e73f1249c9a16d5a479794cb513903e486c05f896e57") -- Call of Duty Modern Warfare II - Co-op - Depot 3603173
setManifestid(3603173, "7667349617666294138", 3307468)
-- Call of Duty Modern Warfare II - DMZ Beta (AppID: 3602970)
addappid(3602970)
addappid(3602970, 1, "f1281334c302cae2aff8688bdcf799fad6fdb5ba746ff190decb3084ecb11366") -- Call of Duty Modern Warfare II - DMZ Beta - Depot 3602970
setManifestid(3602970, "425819475588124927", 9955064808)
addappid(3603176, 1, "f99755c93ad43b98fe8c48c49cbeae75cf4ca41b01c390f8b2eb53e04744d4e2") -- Call of Duty Modern Warfare II - DMZ Beta - Depot 3603176
setManifestid(3603176, "7034086291068148606", 195144340)
addappid(3603177, 1, "aa2d90dcd43e9678ac9f1788313f3d91e6fa5e4cd5947696e48f9df73e46db17") -- Call of Duty Modern Warfare II - DMZ Beta - Depot 3603177
setManifestid(3603177, "4461833380493386193", 397478504)
addappid(3603178, 1, "efd30561a2716070e5fc659a0bb43ec28f49f8b5373e771c008f5386f581fa2e") -- Call of Duty Modern Warfare II - DMZ Beta - Depot 3603178
setManifestid(3603178, "3512893636761887414", 401304196)
addappid(3603179, 1, "f353708bb92df2bea033bd0d41fab46df6e117a148499cce31c334543eb17a4b") -- Call of Duty Modern Warfare II - DMZ Beta - Depot 3603179
setManifestid(3603179, "7746246461522715617", 404951120)
addappid(3603181, 1, "e2d0caf9cd03a2373c12fe315966683777f9fe9952af2cd32cf88d8f65df36b4") -- Call of Duty Modern Warfare II - DMZ Beta - Depot 3603181
setManifestid(3603181, "5418029471378135294", 408522832)
addappid(3603182, 1, "b696e06d847b195d7083fbd047d861e207007f4942b1850715bc7d0d50940215") -- Call of Duty Modern Warfare II - DMZ Beta - Depot 3603182
setManifestid(3603182, "6842233101079690510", 592602340)
addappid(3603183, 1, "d7e71c2a8ce9fc1d024a0a3c58dab9dd9c6bbb74098a3fa0ff5fec2b0e20a37a") -- Call of Duty Modern Warfare II - DMZ Beta - Depot 3603183
setManifestid(3603183, "7145407270375906164", 405301192)
addappid(3603184, 1, "09d2ae039962264fd04af3d2f30722df9aa40260a2d1e3cc7c2555a02233cbbb") -- Call of Duty Modern Warfare II - DMZ Beta - Depot 3603184
setManifestid(3603184, "8164663467183773373", 412668860)
addappid(3603185, 1, "d68f37c8d75e302b0e8a696686ffda6d023443556da7b2b18bf42ac242d31c64") -- Call of Duty Modern Warfare II - DMZ Beta - Depot 3603185
setManifestid(3603185, "6101288156605016710", 390254892)
addappid(3603186, 1, "50c2b01cd4ee40c713e52f494860e9c37a8186846c393d0369e124f084ecff35") -- Call of Duty Modern Warfare II - DMZ Beta - Depot 3603186
setManifestid(3603186, "1069194657375002912", 390283276)
addappid(3603187, 1, "8a9261d96055293904eceb709791a18d1e1b5f64cc0c63c949c3339ab869887b") -- Call of Duty Modern Warfare II - DMZ Beta - Depot 3603187
setManifestid(3603187, "4014277579873269923", 390380288)
addappid(3603188, 1, "e02f5d966b6da9b604633d025e2d21d2a70691ec37b0d7ca008d5eca0aedd584") -- Call of Duty Modern Warfare II - DMZ Beta - Depot 3603188
setManifestid(3603188, "7149387727149794858", 599673068)
addappid(3603189, 1, "70e863d69d7e7c7227848e98641bb3c8df53487835a5021b90196b6a69eb962f") -- Call of Duty Modern Warfare II - DMZ Beta - Depot 3603189
setManifestid(3603189, "7498830346237320479", 601403048)
addappid(3603191, 1, "f86ce3954ccfc22d4b740ebf7e44263d139e497cd51ee8a1d162f8d51db88718") -- Call of Duty Modern Warfare II - DMZ Beta - Depot 3603191
setManifestid(3603191, "4052142946706554531", 608235160)
addappid(3603192, 1, "7d6d927e92774adf0ca91ba37b55947b62a1433a7c2d60e16fddce5195a4bc39") -- Call of Duty Modern Warfare II - DMZ Beta - Depot 3603192
setManifestid(3603192, "1134129829753602538", 202094988)
addappid(3603193, 1, "0cc23692923ca492f15c763f7ea7ae3c563cb0db6da27bed9c8903d1d751a829") -- Call of Duty Modern Warfare II - DMZ Beta - Depot 3603193
setManifestid(3603193, "7557123764704027015", 1542348)
addappid(3603194, 1, "0cbc44b6d2b593a9f7c61c02225165a160d7c820064f5f51724f839417db49f3") -- Call of Duty Modern Warfare II - DMZ Beta - Depot 3603194
setManifestid(3603194, "3399989407408148263", 1542360)
addappid(3603195, 1, "d3a8bd96b861bcf5156788ff19be557bfcf7320d068d84d3a1d5bdb722ba9452") -- Call of Duty Modern Warfare II - DMZ Beta - Depot 3603195
setManifestid(3603195, "5881553120542358298", 1542324)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(3595231) -- Depot 3595231 (empty depot)
-- addappid(3602853) -- Depot 3602853 (empty depot)
-- addappid(3602974) -- Depot 3602974 (empty depot)
-- addappid(3603175) -- Depot 3603175 (empty depot)