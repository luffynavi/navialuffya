-- 4917440's Lua and Manifest Created by Hubcap Manifest
-- MOGGED: Looksmaxx or Die
-- Created: October 02, 2026 at 06:42:00 EDT
-- Website: https://hubcapmanifest.com/
-- Build: 25660873 (public branch)
-- Build Date: October 01, 2026 at 15:18:53 EDT (1790882333)
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4917440) -- MOGGED: Looksmaxx or Die
-- MAIN APP DEPOTS
addappid(4917441, 1, "716d7025642608d2409a921e10a114b204538722d2a56223879ab42f442642b6") -- Depot 4917441
setManifestid(4917441, "8193739099344497468", 4924971689)