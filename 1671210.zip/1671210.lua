-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

-- Generated Lua Manifest by Solus Bot in Morrenus Games
-- Steam App 1671210 Manifest
-- Name: DELTARUNE
-- Generated: 2025-06-04 10:13:02
-- Total Depots: 1
-- Total DLCs: 0 (1 excluded)

-- MAIN APPLICATION
addappid(1671210) -- DELTARUNE

-- MAIN APP DEPOTS
addappid(1671212, 1, "d3b68663ee177c37ee1d5cb49de06cbf9d0d81b2b72ffdde18665f6db6c6ed9f") -- Game Content (Linux Binaries)
setManifestid(1671212, "6530852604090871226", 0)

-- DLCS EXCLUDED (NO DEPOT KEYS, NO DEDICATED DEPOTS)
-- addappid(3752270) -- DELTARUNE Soundtrack (no keys available)
