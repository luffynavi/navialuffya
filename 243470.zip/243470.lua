

-- MAIN APPLICATION
addappid(243470, 1, "3390b2efef88a1d26e3579dde5d9b44e24c04b13f4ff845e71eaed03c064a2f4") -- Watch_Dogs
-- MAIN APP DEPOTS
addappid(243437, 1, "453ae22778c9a046e28bf731c08bb0af550566ad0cc47fdd6a75e8e589c29807") -- Watch Dogs English
setManifestid(243437, "6543707150037666796", 1790331721)
addappid(243472, 1, "adee09eb2f2f87a7fc5bd5abc7a6daef85889156da92e591b198bb6e7066ed25") -- Watch Dogs French
setManifestid(243472, "1774278393062350330", 1715166856)
addappid(243473, 1, "1d449edba5ff3d393d749ad7ea8bc577c4331c3304077f8f4b5d53dc2930195e") -- Watch Dogs German
setManifestid(243473, "7393497789577191823", 1709158665)
addappid(243474, 1, "8cc4873c48760bd3d472680bfaac98003d53453ae5499106891a145d44d1bf02") -- Watch Dogs Italian
setManifestid(243474, "2677117606687932389", 1735060841)
addappid(243475, 1, "27a0151c5291c7402580483b0bfdd52f23ca8be8137ada3ff44e214b4a31d4e4") -- Watch Dogs Swedish
setManifestid(243475, "2641619498238537385", 1789783788)
addappid(243476, 1, "594073c6d5066dfb653a5f25e86d8abb71968c8bb8a0dc9b1335333a3628b96d") -- Watch Dogs Finnish
setManifestid(243476, "6893969456469766077", 1789810445)
addappid(243477, 1, "b4f1f4125b68cb58e579b0e9721d1a11b0702e53667376b2077bcf8ad5aa7680") -- Watch Dogs Norwegian
setManifestid(243477, "4746735065034948169", 1789791525)
addappid(243478, 1, "4c3dba743034ec7845b0f9275b8b5fb8b6a404ddf6a51fbc14ff910def21ca33") -- Watch Dogs Dutch
setManifestid(243478, "5408765191612297193", 1788961050)
addappid(243479, 1, "8194a59d76827d5c6a853c7d28610826d4ce54d4584ec1c3ed0945c16f7cc5f6") -- Watch Dogs Portuguese
setManifestid(243479, "1781482215680542239", 1790554223)
addappid(243480, 1, "2f41dda0871fbd049db13e5b8c93aaed31ec2fa1a4507fb680825bc2c88f3e2f") -- Watch Dogs Brazilian
setManifestid(243480, "2163185997145201045", 1736606991)
addappid(243481, 1, "1ad1e106f29b29021045fb5612bc652122ac6ab4706e389668b7e47c7848c658") -- Watch Dogs Polish
setManifestid(243481, "3669181965975934130", 1789085747)
addappid(243482, 1, "b6b6c54173d11c7c6fbb2d3d227d2367e65be1af56f2bc123fc1f3bd11227714") -- Watch Dogs Japanese
setManifestid(243482, "6839500667345753022", 1728101237)
addappid(243483, 1, "d6f43caf35e3e8daf4e4a862986323a0e8c36054795a60445b4a1641bd01852c") -- Watch Dogs Russian
setManifestid(243483, "3426855786923651137", 1746460363)
addappid(243484, 1, "832dd18b8c9afe55acf05d8e3e515017d8b514dd65e765b4953b2d96b9216a1d") -- Watch Dogs Hungarian
setManifestid(243484, "8917800849169533312", 1789781351)
addappid(243485, 1, "0aeb55622681b144828a6849484dc93183780e441b6b39927beeae067309faea") -- Watch Dogs Czech
setManifestid(243485, "6736938428494126940", 1789778144)
addappid(243486, 1, "50d971a41af68757304374ae351e21830d32a81826ca7e19d71c2623572bd840") -- Watch Dogs Korean
setManifestid(243486, "5022705916316509828", 1789877599)
addappid(243487, 1, "0f3838c855b1d540db4881c89acb9da28b8eb4d07c45832100cdb1b8ea9f62cf") -- Watch Dogs Chinese
setManifestid(243487, "4679331382201445970", 1796309493)
addappid(243488, 1, "cfd8e9b779bd2109bbd9012343bc97404613327295698ea49438488e9e374f83") -- Watch Dogs Spanish
setManifestid(243488, "1897496850595183508", 1743565807)
addappid(293063, 1, "cc1a8f01eb4a11345eb1426b7dfc217515d7f5024a2eb3f01ad10254fd5fbbc8") -- Watch_Dogs RUS
setManifestid(293063, "40897716262624801", 101033749)
addappid(293064, 1, "fcb1eb3608df8698384c34215f8f1d5ed286f5d9c61ea603d5eef88e2ff11f41") -- Watch_Dogs Danish
setManifestid(293064, "3858197885764284729", 1789791547)
addappid(243489, 1, "86697691499c13832dca56937a77ba2d88033449e9fa0ec94184f220ea967f78") -- Watch_Dogs WW
setManifestid(243489, "362035036454864186", 109784131)
addappid(243471, 1, "77184dab3ba78bfc47c7a4de0a466dcecc808954c08be694e6772e5efdca2d21") -- Watch Dogs Common
setManifestid(243471, "5582561119037069284", 12728690915)
addappid(300668, 1, "10f6f19ea39ad6c757590a877d7c7a6686e479e21af0a7754d942160102d1cb0") -- Watch_Dogs Chinese Simplified
setManifestid(300668, "6878173766487895011", 1789752669)
-- SHARED DEPOTS (from other apps)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
setManifestid(228982, "6413394087650432851", 9688647)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- .NET 3.5 Redist (Shared from App 228980)
setManifestid(229000, "4622705914179893434", 242743889)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- .NET 3.5 Client Profile Redist (Shared from App 228980)
setManifestid(229001, "4049573910112143457", 267964564)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
setManifestid(1716751, "8936186649444731600", 264933784)
-- DLCS WITH DEDICATED DEPOTS
-- Watch_Dogs Season Pass (AppID: 293054)
addappid(293054)
addappid(293054, 1, "6a07e87977d2328dfb2ca918bf228022d5a6d1d02fb86a29f3e460bd8ce415cf") -- Watch_Dogs Season Pass - Watch_Dogs Season Pass Uplay Activation (293054) Depot
setManifestid(293054, "3534712475932838237", 525)
-- Watch_Dogs - Deluxe Edition Exclusive Content (AppID: 293055)
addappid(293055)
addappid(293055, 1, "07308d946c4eb0c38ed54ddec03e7dc70cbd9905f16aafb23f4ebb1366eeedf4") -- Watch_Dogs - Deluxe Edition Exclusive Content - Watch_Dogs - DLC 0 (293055) Depot
setManifestid(293055, "7966729444078833786", 28037350)
-- Watch_Dogs - Conspiracy  (AppID: 293057)
addappid(293057)
addappid(293057, 1, "95474de677410428364ae70a1f391406da35f6d14b72dda6a7aa42a5040757e5") -- Watch_Dogs - Conspiracy  - Watch_Dogs - DLC 1 (293057) Depot
setManifestid(293057, "3489527419200560368", 30841083)
-- Watch_Dogs - Access Granted Pack (AppID: 293059)
addappid(293059)
addappid(293059, 1, "c3e377b39e27482ab87c3cd9fe1beb790a8252bf15b914898f3382b5a31f231b") -- Watch_Dogs - Access Granted Pack - Watch_Dogs - DLC 2 (293059) Depot
setManifestid(293059, "6421005004532097582", 1147)
-- Watch_Dogs Bad Blood (AppID: 293061)
addappid(293061)
addtoken(293061, "12130676317065299263")
addappid(293061, 1, "b6875dd3b7ed1e9c2a8e1ddbb62626e2f4302fc2eefd01b2fbae3b09b5718a8c") -- Watch_Dogs Bad Blood - Watch_Dogs - DLC 3 (293061) Depot
setManifestid(293061, "4116348827715489844", 3718567700)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(298781) -- Watch_Dogs - Uplay Activation
addappid(298782) -- Watch_Dogs - Deluxe Edition Preorder Uplay Activation
addappid(298783) -- Watch_Dogs - Deluxe Edition Uplay Activation
addappid(298784) -- Watch_Dogs - Season Pass Uplay Activation
addappid(298785) -- Watch_Dogs - Deluxe Edition Exclusive Content Uplay Activation
addappid(298786) -- Watch_Dogs - Conspiracy Uplay Activation
addappid(298788) -- Watch_Dogs - Bad Blood Uplay Activation
addappid(298910) -- Watch_Dogs - Preorder Uplay Activation (RU)
addappid(298911) -- Watch_Dogs - Uplay Activation (RU)
addtoken(298911, "3065787327939462993")
addappid(298913) -- Watch_Dogs - Deluxe Edition Uplay Activation (RU)
addtoken(298913, "15265792249588161980")
addappid(300660) -- Watch_Dogs - Preorder Uplay Activation (ASIA)
addappid(300661) -- Watch_Dogs - Uplay Activation (ASIA)
addappid(300662) -- Watch_Dogs - Deluxe Edition Preorder Uplay Activation (ASIA)
addappid(300663) -- Watch_Dogs - Deluxe Edition Uplay Activation (ASIA)
addappid(303890) -- Watch_Dogs - Preorder Uplay Activation
addappid(303920) -- Watch_Dogs - Deluxe Edition Preorder Uplay Activation (RU)
addappid(303960) -- Watch_Dogs - Access Granted Pack Uplay Activation
addtoken(303960, "12387094823720109792")
-- EMPTY DEPOTS (no content on any branch)
-- addappid(298919) -- Depot 298919 (empty depot)