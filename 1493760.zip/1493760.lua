addappid(1493760)
addappid(1493761,0,"7dacf7699064cc15ccfd1b982a0dd77e4f8c2ec9f87647267a4b98d9f2033b6b")
setManifestid(1493761,"5791998497781929113")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]