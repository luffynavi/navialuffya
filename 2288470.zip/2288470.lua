addappid(2288470)
addappid(2288471, 1, "a6f02b8c9aec331ef154cbc269be48029dc44f5682779fbf4e176152d73ac1e2")
setManifestid(2288471, "6387322761831360463", 5526285991)




--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]