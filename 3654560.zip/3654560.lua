addappid(3654560)
addappid(3654561,0,"6fc167060f8d59e04b1336aa831531599eba25b5d81a6d659408e1d69b65b456")
addappid(3802680)


--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]