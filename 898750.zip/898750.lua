addappid(898750)
addappid(898751,0,"f553ceb7b38d428cab2a8122991fcc8906b1628f86a32f4a3639da017591703a")
setManifestid(898751,"8968546590395848207")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]