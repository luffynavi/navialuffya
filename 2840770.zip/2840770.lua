-- MAIN APPLICATION
addappid(2840770) -- Avatar: Frontiers of Pandora
-- MAIN APP DEPOTS
addappid(2840771, 1, "64292a119e4b390ef4488dd942329a7794234989b74c79e3228adb22bfd9d4e9") -- Depot 2840771
setManifestid(2840771, "4453046820083378963", 90724417826)
addappid(2840772, 1, "00c6fe38e74b05f6dc70d62fd74a6e8f4eeb91d9e7b9db53368a991173c9e10a") -- Depot 2840772
setManifestid(2840772, "591329598511062425", 2595118438)
addappid(2840773, 1, "318c6390e6722d953e5d87462e9ef7b523aaae813fc3e4fdb0b8c409217ba832") -- Depot 2840773
setManifestid(2840773, "1685669709126676964", 2711804563)
addappid(2840774, 1, "9b994fdd7426be8a12fccb94c5e7f0fa17467a0f210941d82c54e2308d547853") -- Depot 2840774
setManifestid(2840774, "6925198600522292954", 2824145993)
addappid(2840775, 1, "119fce59e34c3146f02c4d5177801f6262085810b15b230bde3e59beb8510737") -- Depot 2840775
setManifestid(2840775, "4119199569999406077", 2859068225)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
setManifestid(1716751, "4835530931043548961", 259065496)
-- DLCS WITH DEDICATED DEPOTS
-- Avatar Frontiers of Pandora  The Sky Breaker (AppID: 3005000)
addappid(3005000)
addappid(3005000, 1, "bb5b5446892c4e6b050d88e7e41f1d775f39970ea3d5998380d59084bcd5f5d4") -- Avatar Frontiers of Pandora  The Sky Breaker - Depot 3005000
setManifestid(3005000, "3622577447599532774", 6154105311)
-- Avatar Frontiers of Pandora  Secrets of The Spire (AppID: 3005010)
addappid(3005010)
addappid(3005010, 1, "3fefd54093821f0ae2793878338384715c8b4061d70ae3a04e4fb281684c0af0") -- Avatar Frontiers of Pandora  Secrets of The Spire - Depot 3005010
setManifestid(3005010, "180239973104301789", 10323942961)
-- From The Ashes Expansion - Avatar Frontiers of Pandora (AppID: 3823590)
addappid(3823590)
addappid(3823590, 1, "c19fc428ff111dd82c4f076e4c19c65ee8377a1b5e1d945d6040cdbcb85e49b5") -- From The Ashes Expansion - Avatar Frontiers of Pandora - Depot 3823590
setManifestid(3823590, "1935510411987452", 25066451433)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2857020) -- Avatar Frontiers of Pandora DELUXE Ubisoft Activation
addappid(2857030) -- Avatar Frontiers of Pandora GOLD Ubisoft Activation
addappid(2857040) -- Avatar Frontiers of Pandora ULTIMATE Ubisoft Activation
addappid(2857260) -- Avatar Frontiers of Pandora  Season Pass
addappid(2857270) -- Avatar Frontiers of Pandora  Season Pass Ubisoft Activation
addappid(2857300) -- Sky Rider Starter Pack  Avatar Frontiers of Pandora
addappid(2857310) -- Avatar Frontiers of Pandora Starter Pack Ubisoft Activation
addappid(2857390) -- Avatar Frontiers of Pandora Ubisoft Activation
addappid(3087130) -- Avatar Frontiers of Pandora The Sky Breaker DLC Ubisoft Activation
addappid(3228830) -- Avatar Frontiers of Pandora Secrets of the Spires DLC Ubisoft Activation
addappid(3231160) -- Storm Chaser Starter Pack - Avatar Frontiers of Pandora
addappid(3231170) -- Avatar Frontiers of Pandora - Storm Chaser Starter Pack Ubisoft Activation
addappid(3830230) -- From The Ashes Expansion - Avatar Frontiers of Pandora Ubisoft Activation
addappid(3914600) -- JAKE SULLY TORUK MAKTO STARTER PACK - AVATAR FRONTIERS OF PANDORA
addappid(3914610) -- Avatar Frontiers of Pandora - Starter pack - Jake Sully Toruk Makto Ubisoft Activation
addappid(3914620) -- VALLEY OF MOARA STARTER PACK - AVATAR FRONTIERS OF PANDORA
addappid(3914630) -- Avatar Frontiers of Pandora - Valley of Moara Starter pack Ubisoft Activation
addappid(3914640) -- Avatar Frontiers of Pandora From the Ashes Edition Ubisoft Activation
addappid(3914650) -- Avatar Frontiers of Pandora Complete Edition Ubisoft Activation
addappid(3915910) -- From The Ashes Expansion - Avatar Frontiers of Pandora
addappid(3915920) -- Avatar Frontiers of Pandora - Preorder DLC Maximus  - Ubisoft Activation