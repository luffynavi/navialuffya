addappid(3039910)
addappid(3039911, 1, "c0d70c21f69ef19ee644e2676cdcec58f44969c4cef9264c6495d214e16dcba2")
setManifestid(3039911, "8533107590005182944", 911540245)


--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]