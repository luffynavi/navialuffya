addappid(3604780)
addappid(3604781,0,"a036bd4e3defc8480995efd799ee4dccab61dc0d57dd3ee43bfb31ddb37a7444")
setManifestid(3604781,"7294299937346263511")



--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]
