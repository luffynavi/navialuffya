addappid(3850560)
addappid(3850561,0,"61903c2633e62e94d33f313bfefafd29b2e47475366438e3d01d2b7832001567")
--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]