-- 1636440's Lua and Manifest Created by Hubcap Manifest
-- SILENT HILL: Townfall
-- Created: September 22, 2026 at 08:22:03 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 8
-- Total DLCs: 0
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(1636440, 1, "7b557e5bf973f343233a3b034f3cb02815f94ba267a7c92e0b335b30c4176e5a") -- SILENT HILL: Townfall
-- MAIN APP DEPOTS
addappid(1636441, 1, "62c41fd0ab66ae0f82f86b835f333bc9ec55fb5d28ee696b599a745059bb62ce") -- Depot 1636441
setManifestid(1636441, "5846939894323649224", 75874080816)
addappid(4126670, 1, "7d1a555b80ecea1b26fe05d48beafaf2745f6f3851e6e691bb8d085421892f99") -- Depot 4126670
setManifestid(4126670, "2957044820498811960", 31457238)
addappid(4235620, 1, "556a8c2ff138b8d8b54f00f607af240c1bd58e07e3a9ea92f9a1881fcb1ab522") -- Depot 4235620
setManifestid(4235620, "1453085193393980489", 62368873)
addappid(4663210, 1, "86c4decc818889e1d669912dd971ff721cc2136ab9fdbb68de06c2f2e919daf1") -- Depot 4663210
setManifestid(4663210, "879371378507688417", 3012953716)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- .NET 4.8 Redist (Shared from App 228980)
setManifestid(229007, "4477590687906973371", 117381405)