

-- MAIN APPLICATION
addappid(2373990, 1, "907973645448aa77cf21b57183812bea5a58a29df75bfc0a4dc37bc6bdff0371") -- Solo Leveling: ARISE OVERDRIVE
-- MAIN APP DEPOTS
addappid(2373991, 1, "5a97586d39bdb2a503376a75e3cae7d1f7e2de1bcb9ced523a73b21ca79de413") -- Depot 2373991
setManifestid(2373991, "1489289555529536886", 48178598135)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3638570) -- Solo LevelingARISE OVERDRIVE - Deluxe Edition
addappid(4240370) -- Solo LevelingARISE OVERDRIVE - Christmas Costume Gift Pack
addappid(4710940) -- Solo LevelingARISE OVERDRIVE - Jeju Island Raid Special Pack