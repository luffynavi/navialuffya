addappid(3259600)
addappid(3259601, 1, "ae634a9eec6e2ae45901364376e5c088e269ae26071c8b7741b4a9b681bdf85c")
addappid(3811090)
addappid(3811090, 1, "c6402a39e57409af780a6941b3eb551458899ac990877fc4eae4085a0e6cd963")
addappid(3811110)
addappid(3811110, 1, "fdb0f863798896be92f76b7738c9a5e7a6c9b6616d4afd4e28216cbae0aa631f")
addappid(3811120)
addappid(3811130)
addappid(3811130, 1, "3b21d7253db784922ca1da073dc42392f86a5587d1df1ed179a785d0a566e4bd")
addappid(3811180)
addappid(3811180, 1, "1b0ebc42b6b1c083f7dc0eaa131088d447042cd8e0d680f449dd3a8e00e79ac0")



--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]
