addappid(3401920) -- Upin & Ipin Universe
addappid(3401921, 1, "1ed51cfdf48a0b8fd26e081ce4b7c70a17e0a028d99b3a0100ad2dd8f840e9f6") -- Depot 3401921
setManifestid(3401921, "1915934642467745943", 0)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)