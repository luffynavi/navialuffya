addappid(2358720)
-- MAIN APP DEPOTS
addappid(2358721, 1, "78d5a284965b2206de191dc4ca99d43c9caf5b5e78b47cf0c366fbbb884190d8") -- Depot 2358721
setManifestid(2358721, "143266280896848005", 149849171629)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- .NET 4.7 Redist (Shared from App 228980)
setManifestid(229006, "1784011429307107530", 83944258)
-- DLCS WITH DEDICATED DEPOTS
-- Black Myth Wukong Deluxe Edition Upgrade (AppID: 2672610)
addappid(2672610)
addappid(2672611, 1, "9f7513ce3953f71d2f994a9a331b862c8a41aeae89b0ff0933336aeef1796220") -- Black Myth Wukong Deluxe Edition Upgrade - Depot 2672611
setManifestid(2672611, "1995373587248188296", 0)