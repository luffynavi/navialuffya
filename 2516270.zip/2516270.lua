-- 2516270's Lua and Manifest Created by Hubcap Manifest
-- Pa!nt
-- Created: August 23, 2026 at 00:25:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2516270, 1, "0abcc3451d7ea52d68a5f2a39fadfbd15d2c5e171bd08fa78862faf39286d437") -- Pa!nt
-- MAIN APP DEPOTS
addappid(2516271, 1, "748ad2310ad0085383dcc58bac667f5c2b93e3f404ac33568e0a5e45fe910060") -- Depot 2516271
setManifestid(2516271, "5898119487068805083", 220826008)
addappid(2516272, 1, "6dc3bfc6d2aa3f4bfcbc4ff2f7356d2793cd3342ab9009fa445fea212625f89f") -- Depot 2516272
setManifestid(2516272, "2873317065785634515", 241589477)