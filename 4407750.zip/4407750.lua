-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 4407750.lua
--Gamename EA SPORTS FC™ 27 Lite
addappid(4407750) --Mainappid EA SPORTS FC™ 27 Lite
addappid(4407751, 1, "391fb01c94176fe28e2f260e03ed3b52f00b3e410d1509fc4dca08781c3e6ed3") --Main Windows Depot EA SPORTS FC™ 27 Lite
setManifestid(4407751, "2525593685451812285", 64)
--Share Depots
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228989, "5753583882400741046", 25108528)
addappid(3340991, 1, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491") --Share Windows Depot EA APP Installer
setManifestid(3340991, "556631282418311229", 253708064)
addappid(3893181, 1, "7f675c2fe8e758d16f3cf8d3b493956afaee78e96d78cdb668a5edb8ac1580f6") --Share Windows Depot EA Javelin Anticheat Installer
setManifestid(3893181, "4405530693997782804", 334463536)
addappid(4080221, 1, "7049f0ef11b8ebe50c06c4543fe973208ba01b2d8da3069e108627fbf352cce4") --Share Windows Depot EA SPORTS FC™ 27
setManifestid(4080221, "5268752611597929425", 70954421376)
addappid(4080223, 1, "0573bfe3d4f8b5d2734b56489765324c3df348252909d8bd0687e15ce907a45b") --Share Windows Language Depot Swedish EA SPORTS FC™ 27
setManifestid(4080223, "5287758689750855853", 63248)
addappid(4080224, 1, "fa1acba06d8e53e502007d40cce2f465d0f11e333e3be79dbe670bf7569c133b") --Share Windows Language Depot German EA SPORTS FC™ 27
setManifestid(4080224, "1377001121128795507", 5204288)
addappid(4080225, 1, "6dd81776a48dc671a16191048c046607a79ab4013dadaf3112678d973e3b59c3") --Share Windows Language Depot English EA SPORTS FC™ 27
setManifestid(4080225, "5739380745518978550", 48336)
addappid(4080226, 1, "773b9f7b9f5a017021c1210016fa5712f25b1034f6ea32ac5097cc071308c13e") --Share Windows Language Depot French EA SPORTS FC™ 27
setManifestid(4080226, "5942881338456530918", 5239312)
addappid(4080227, 1, "0821c95d0360dfcdc552c2de7118b4fed735bc21f333c678cb09f78bd5bdc591") --Share Windows Language Depot Italian EA SPORTS FC™ 27
setManifestid(4080227, "7679856652678426753", 5419904)
addappid(4080228, 1, "0668b1ca3b4ae8b3c1e8ffbf98f2113b24c72450a400dcb022f96730a276b774") --Share Windows Language Depot Koreana EA SPORTS FC™ 27
setManifestid(4080228, "794484118145182571", 1344540784)
addappid(4080229, 1, "847343c0863a7cb9671b65ab73c5a1189b40336f6f730dc4fd59cb5cb80a6aee") --Share Windows Language Depot Spanish EA SPORTS FC™ 27
setManifestid(4080229, "7106953542147231829", 5609904)
addappid(4080261, 1, "82236ba461d7223a5639914e8e3218f4bed8dffa99eaa6e1126eac8302c7d6d8") --Share Windows Language Depot Schinese EA SPORTS FC™ 27
setManifestid(4080261, "7794824977427195846", 1425006544)
addappid(4080262, 1, "7623a491ada9aa3c66fb115e6806b1d18e76952ce5ab3e23b25632eb2f214254") --Share Windows Language Depot Tchinese EA SPORTS FC™ 27
setManifestid(4080262, "9008810652663464132", 60624)
addappid(4080263, 1, "e83e3fe2b272babfc141b8d01d702aa7e07021004552a7fd0a044ba0fd6e3076") --Share Windows Language Depot Russian EA SPORTS FC™ 27
setManifestid(4080263, "8007499312876902863", 2342880)
addappid(4080264, 1, "57c6089562785df9880fa8af499fa64e0400798cc753e8e3aa128bcdab12a96c") --Share Windows Language Depot Japanese EA SPORTS FC™ 27
setManifestid(4080264, "5245311515457934438", 1714479440)
addappid(4080265, 1, "3fb5f73a06b7503c3bd74958ce1321884230ed85b835658e95d9b855cf96d2c4") --Share Windows Language Depot Portuguese EA SPORTS FC™ 27
setManifestid(4080265, "4353363556734767404", 63120)
addappid(4080266, 1, "454be933df9a0720926f2edd97d069e879460f5545abfb62169a1924490ba7d5") --Share Windows Language Depot Polish EA SPORTS FC™ 27
setManifestid(4080266, "1586036173309829194", 1719207936)
addappid(4080267, 1, "04489429055546441092e4770120b9510acd8af3da0cb628b288c6786479ff14") --Share Windows Language Depot Danish EA SPORTS FC™ 27
setManifestid(4080267, "6637253751845598633", 62544)
addappid(4080268, 1, "88a78c4c2533d41ae630cec04f300ddd036446a76610582f07fce03e387b6f28") --Share Windows Language Depot Dutch EA SPORTS FC™ 27
setManifestid(4080268, "238897346385244565", 1761061408)
addappid(4080269, 1, "6345670be2dc65acf2de2d327577645a049a3c31928729be7c84ec1a7f6ee741") --Share Windows Language Depot Norwegian EA SPORTS FC™ 27
setManifestid(4080269, "2060310763973999219", 61968)
addappid(4160760, 1, "15e8d4fc8ce2f557f097de8b931b420de5441b9b30d9f57548d36790cbf92a0c") --Share Windows Language Depot Czech EA SPORTS FC™ 27
setManifestid(4160760, "8004290822224116802", 69184)
addappid(4160761, 1, "34ea8a902031313afc19fc07112d87f7ab7a5f61d1519f94788e2684ad0f4d70") --Share Windows Language Depot Turkish EA SPORTS FC™ 27
setManifestid(4160761, "4571320865101431864", 1429637104)
addappid(4160762, 1, "74e0165849379dc39f62c32f14f581cde89df83128e7e8b1f884a5047554d38e") --Share Windows Language Depot Arabic EA SPORTS FC™ 27
setManifestid(4160762, "2114508896486376158", 1898939552)
addappid(4160763, 1, "056ab5df670e8a6d546b48cf2f30c6fda08e7c7f78f9a267425bb3c50e2bb2ad") --Share Windows Language Depot Brazilian EA SPORTS FC™ 27
setManifestid(4160763, "7743356554738382064", 1875365280)
addappid(4160764, 1, "0631805b76b7d3e0e6a4be26e79a01b9810087c6cd3aea02f77d7e969c7a8c1a") --Share Windows Language Depot Latam EA SPORTS FC™ 27
setManifestid(4160764, "1173922674387606642", 1649801504)
addappid(4407660) --Dlcname EA SPORTS FC™ 27 Lite