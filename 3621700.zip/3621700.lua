addappid(3621700)
addappid(3621701,0,"35dd000f8d81beb18530ad42b5897f0103edb789bcce42b58a1873c178f83b9b")
--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]