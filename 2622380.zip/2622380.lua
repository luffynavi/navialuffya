-- Generated Lua Manifest by Solus Bot in Morrenus Games
-- Steam App 2622380 Manifest
-- Name: ELDEN RING NIGHTREIGN
-- Generated: 2025-06-10 23:21:44
-- Total Depots: 4
-- Total DLCs: 4
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2622380) -- ELDEN RING NIGHTREIGN

-- MAIN APP DEPOTS
addappid(2622381, 1, "c3e9ccfedcda0cd10e53938e15261130b2e166007d2ca8f13aa5a05f06bd2630") -- Main Game Content (Windows Content)
setManifestid(2622381, "1414850870793307718", 0)
addappid(2622383, 1, "c6e496ba5ae5c8bfa358f3a7d923ec39964fa0a41c4fa77006249fe34e677af2") -- Game Content (Mac Content)
setManifestid(2622383, "5185881824563081547", 0)

-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3319490) -- ELDEN RING NIGHTREIGN Bonus Gesture
addappid(3515610) -- ELDEN RING NIGHTREIGN - Deluxe Upgrade Pack
addappid(3637850) -- ELDEN RING NIGHTREIGN CE Content (Retail)
