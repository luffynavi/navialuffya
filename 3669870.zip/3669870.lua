-- 3669870's Lua and Manifest Created by Hubcap Manifest
-- CONTROL Resonant
-- Created: September 24, 2026 at 10:52:10 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 5
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3669870, 1, "e53df1456a5d9cb4244af0790bfecf0b7f24217faf8a20276ce03b302187f51e") -- CONTROL Resonant
addtoken(3669870, "18274421760595271558")
-- MAIN APP DEPOTS
addappid(3669871, 1, "47ad456f9070a97f6206e13818d3588f48e26d8d94675b45f481b32ae2fc0bd5") -- Depot 3669871
setManifestid(3669871, "5962114018493126939", 112203821551)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4403940) -- CONTROL Resonant Digital Deluxe Upgrade
addappid(4760150) -- CONTROL Resonant Digital Deluxe Edition - Original Soundtrack and Digital Artbook
addtoken(4760150, "11635387767932080005")
addappid(4760160) -- CONTROL Resonant Digital Deluxe Edition - Untapped Artifact (Wallet)
addtoken(4760160, "4968652230313847411")
addappid(4760170) -- CONTROL Resonant Digital Deluxe Edition - Starter Resource Bundle
addtoken(4760170, "7759855539969402306")
addappid(4760190) -- CONTROL Resonant Digital Deluxe Edition - AWE Mission Outfit
addtoken(4760190, "12349664922998478843")