-- Base Game: Poppy Playtime
addappid(1721470)

-- Main Application
addappid(4100940, 1, "527fa72d80412026553480eaf2d04230eee3d58c07d133d290b72be6d664fe75")
