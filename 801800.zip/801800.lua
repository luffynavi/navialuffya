-- 801800's Lua and Manifest Created by Hubcap Manifest
-- Atomfall
-- Created: September 18, 2026 at 08:35:12 EDT
-- Website: https://hubcapmanifest.com/
-- Build: 20373765 (public branch)
-- Build Date: October 13, 2025 at 13:54:25 EDT (1760378065)
-- Total Depots: 6
-- Total DLCs: 5
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(801800, 1, "abfa7ec426e2b372358220592d5887097e9c21db8d6c0db0431abe7b672cac6f") -- Atomfall
addtoken(801800, "17496527365609371616")
-- MAIN APP DEPOTS
addappid(801801, 1, "90c65d444ba102f30b701ec00443031dc75907d1a98526fa98597697012055c6") -- Depot 801801
setManifestid(801801, "8400971978754919400", 309257064)
addappid(801802, 1, "d5a28674f8d766073a2923af03b553720f7878451afad54be20e9c24d62406a0") -- Depot 801802
setManifestid(801802, "1398041519600569249", 70544236820)
addappid(801803, 1, "d7049ae7ee8ee2e9451254724c7169645ba6022a1d72446e2ac621c0e9eb8dbb") -- Depot 801803
setManifestid(801803, "7265483314431453939", 1822568)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
-- DLCS WITH DEDICATED DEPOTS
-- Atomfall Story Expansion Pack Wicked Isle (AppID: 3047140)
addappid(3047140)
addtoken(3047140, "4195917910091754303")
addappid(3047140, 1, "7ebc92e9ae8bd45b1a68f502a093ee8f8769f3c27184c88438c5e202e89bc995") -- Atomfall Story Expansion Pack Wicked Isle - Depot 3047140
setManifestid(3047140, "8053094571818646338", 5127692235)
-- Atomfall Story Expansion Pack The Red Strain (AppID: 3252020)
addappid(3252020)
addappid(3252020, 1, "8b3001891ce408235534800ccb914ef87e74704cc6c906c34873e447cb8e5c29") -- Atomfall Story Expansion Pack The Red Strain - Depot 3252020
setManifestid(3252020, "1656463850248702710", 2981636399)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3047130) -- Atomfall Basic Supply Bundle
addtoken(3047130, "7844257334683668899")
addappid(3047150) -- Atomfall Enhanced Supply Bundle
addtoken(3047150, "14348286297748652806")
addappid(3607720) -- Atomfall Deluxe Upgrade