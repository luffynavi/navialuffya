-- Steam App 490110 Manifest
-- Name: The Precinct
-- Generated: 2025-05-14 12:17:01
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(490110) -- The Precinct

-- MAIN APP DEPOTS
addappid(490111, 1, "44bcc3870bf156385e37ff47e71ae28824fa905a542cdc8eaf05715799f78fc2") -- Main Game Content (Windows Content)
setManifestid(490111, "7702403660824377816", 0)
