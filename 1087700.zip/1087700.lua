addappid(1087700)
addappid(1087701,0,"8b81e4d0bcca2f23fcc0c850ed5e21208093e84bfe01f7116277b89bc97daf9d")
--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]