

-- MAIN APPLICATION
addappid(3500390, 1, "ce78d0d31240d39462ce0f1ec89e60b7d5cbe3266c80a66681a647a59491ab02") -- Mega Man Star Force Legacy Collection
-- MAIN APP DEPOTS
addappid(3500391, 1, "febf6d8948ae4c2e1a199fa36f58cbfd6c5b3d81c130a612604f803316f5326b") -- Depot 3500391
setManifestid(3500391, "1559870207820393768", 5252789383)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
-- DLCS WITH DEDICATED DEPOTS
-- Mega Man Star Force Legacy Collection  Geo Stelar and Omega-Xis Character Model Pack (AppID: 4059840)
addappid(4059840)
addappid(4059840, 1, "e36991eb8125945b9f99b2c11323010a5a918ad3f07b8bb7dc199a5cb4c49b42") -- Mega Man Star Force Legacy Collection  Geo Stelar and Omega-Xis Character Model Pack - Depot 4059840
setManifestid(4059840, "2274394409022129768", 50345033)
-- Mega Man Star Force Legacy Collection  Mega Man Battle Network Series BGM (AppID: 4059850)
addappid(4059850)
addappid(4059850, 1, "53e2bea43b75aa1da51ae5db09413e9c1cc98f99de9b4b787fea8c2eeefcf45c") -- Mega Man Star Force Legacy Collection  Mega Man Battle Network Series BGM - Depot 4059850
setManifestid(4059850, "1340711804696207363", 225964166)
-- Mega Man Star Force Legacy Collection  Sonia Strumm and Luna Platz Character Model Pack (AppID: 4059860)
addappid(4059860)
addappid(4059860, 1, "a4a1b191f1d28dd691f0e9197d0f156a0781b407a466d44a7e455aa97903b032") -- Mega Man Star Force Legacy Collection  Sonia Strumm and Luna Platz Character Model Pack - Depot 4059860
setManifestid(4059860, "1976583030948263159", 16410091)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4390970) -- Depot 4390970 (empty depot)