-- 2971750's Lua and Manifest Created by Morrenus
-- 雙面夜孃
-- Created: October 28, 2025 at 16:15:52 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2971750) -- 雙面夜孃
-- MAIN APP DEPOTS
addappid(2971751, 1, "57d20028af82ef5ff2b0bdc9697892fe8be55ca0c9add9a01a83a9d123008654") -- Depot 2971751
setManifestid(2971751, "4150085586273221214", 1078877728)