addappid(2896760)
addappid(2896761,0,"00fb982a00a8841eedaa031a2f7a335956be3e924df8de62d1091170264312fa")
--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]